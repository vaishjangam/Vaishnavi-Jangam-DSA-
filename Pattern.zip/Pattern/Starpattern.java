/* Make a pattern: *
                  **
                  ***
                  ****
                  ****** 
*/

import java.util.*;
public class Starpattern{
    public static void main(String arg[]){
        for(int line=1; line<=5; line++){
            for(int star=1; star<=line; star++){
                System.out.print("*");
            }
            System.out.println("");
        }
    }
}
