import java.util.*;
public class BasicFunction{
    public static void PrintHelloworld(){ //function block
        System.out.println("Hello world!!");
        System.out.println("Hello world!!");
        System.out.println("Hello world!!");
        System.out.println("Hello world!!");
        System.out.println("Hello world!!");
        return;
        }

    public static void main(String args[]){//main function

        PrintHelloworld();//function call
    }
}